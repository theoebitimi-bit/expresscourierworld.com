# Express Courier — website starter

This is a functional starter application with:
- Responsive public website
- Tracking lookup backed by a local SQLite database
- Quote/support enquiry form saved to the database
- Optional email notifications through SMTP
- Staff login, shipment creation and tracking-event updates
- WhatsApp, email and live-chat connection points

## Important before going live
This starter is not yet a licensed carrier integration or a production-ready global logistics platform. It does not connect to postal/courier carrier networks, calculate live shipping rates, generate labels, accept payments, or prove delivery. Add only services and destinations your business is authorized and able to serve. Tracking updates must be entered from verified shipment events.

## Run locally
1. Install Node.js 20 or later.
2. Extract this folder.
3. Copy `.env.example` to `.env`.
4. Set a strong `SESSION_SECRET`, `ADMIN_EMAIL`, and `ADMIN_PASSWORD`.
5. Set your real `SUPPORT_EMAIL` and WhatsApp number (international format, digits only).
6. Run `npm install`.
7. Run `npm start`.
8. Visit `http://localhost:3000`; staff portal: `http://localhost:3000/admin.html`.

## Email
For automatic email notifications, fill in SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, MAIL_FROM and SUPPORT_EMAIL. Use credentials from your chosen email provider. Enquiry submissions are saved even if SMTP is not configured.

## WhatsApp
Set WHATSAPP_NUMBER in international format without `+`, spaces or punctuation. The website opens a WhatsApp chat link; it does not send messages automatically.

## Live chat
Choose a live-chat provider, create an account, and use its official embed/script URL in LIVE_CHAT_SCRIPT_URL. The button is a fallback until the provider's widget is configured.

## Production deployment checklist
- Buy a domain from a reputable registrar and configure DNS.
- Deploy to a Node.js host with HTTPS.
- Use persistent storage/volume for `express-courier.sqlite`, or migrate to managed PostgreSQL.
- Configure secure session storage (not the default in-memory session store), secure cookies, backups, monitoring and automated updates.
- Use a reverse proxy or hosting platform HTTPS.
- Add CSRF protection, stronger validation, audit logs, account lockout/MFA and role-based staff access before production.
- Add privacy policy, terms, prohibited-items policy, claims process, shipping restrictions, company registration and verified physical contact details.
- Connect real carrier APIs or a verified operations workflow before advertising carrier-level tracking or delivery estimates.
- Test admin access, enquiry delivery, backups, tracking and mobile layout before launch.

## Database
The SQLite database is created automatically in the project directory. Back it up regularly. Do not delete it after real customer records have been entered.
