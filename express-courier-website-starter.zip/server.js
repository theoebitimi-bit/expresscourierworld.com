require("dotenv").config();
const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const nodemailer = require("nodemailer");
const path = require("path");

const app = express();
const db = new Database("express-courier.sqlite");
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS shipments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tracking_number TEXT UNIQUE NOT NULL,
  recipient TEXT NOT NULL,
  destination TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Shipment information received',
  updated_at TEXT NOT NULL,
  events TEXT NOT NULL DEFAULT '[]'
);
CREATE TABLE IF NOT EXISTS enquiries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  message TEXT NOT NULL,
  created_at TEXT NOT NULL
);
`);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "30kb" }));
app.use(express.urlencoded({ extended: false }));
app.use(session({
  name: "ec_admin",
  secret: process.env.SESSION_SECRET || "development-only-change-this",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "strict", secure: process.env.NODE_ENV === "production", maxAge: 60 * 60 * 1000 }
}));
app.use("/api/", rateLimit({ windowMs: 15 * 60 * 1000, limit: 100 }));
app.use(express.static(path.join(__dirname, "public")));

const clean = (v, max=500) => String(v || "").trim().slice(0, max);
const adminOnly = (req, res, next) => req.session && req.session.admin ? next() : res.status(401).json({ error: "Admin sign-in required." });

app.get("/api/config", (req, res) => res.json({
  supportEmail: process.env.SUPPORT_EMAIL || "",
  whatsappNumber: process.env.WHATSAPP_NUMBER || "",
  liveChatScriptUrl: process.env.LIVE_CHAT_SCRIPT_URL || ""
}));

app.get("/api/track/:number", (req, res) => {
  const number = clean(req.params.number, 40).toUpperCase();
  const row = db.prepare("SELECT tracking_number, recipient, destination, status, updated_at, events FROM shipments WHERE tracking_number = ?").get(number);
  if (!row) return res.status(404).json({ error: "No shipment was found for that tracking number. Check the number or contact customer support." });
  res.json({ ...row, events: JSON.parse(row.events) });
});

app.post("/api/enquiry", async (req, res) => {
  const kind = clean(req.body.kind, 30);
  const name = clean(req.body.name, 100);
  const email = clean(req.body.email, 160);
  const message = clean(req.body.message, 2000);
  if (!["quote", "support"].includes(kind) || !name || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || message.length < 5) {
    return res.status(400).json({ error: "Please provide a name, valid email address, and a message." });
  }
  db.prepare("INSERT INTO enquiries (kind,name,email,message,created_at) VALUES (?,?,?,?,?)")
    .run(kind, name, email, message, new Date().toISOString());
  if (process.env.SMTP_HOST && process.env.SUPPORT_EMAIL) {
    try {
      const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST, port: Number(process.env.SMTP_PORT || 587),
        secure: process.env.SMTP_SECURE === "true",
        auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined
      });
      await transporter.sendMail({
        from: process.env.MAIL_FROM || process.env.SMTP_USER,
        to: process.env.SUPPORT_EMAIL,
        subject: `Express Courier ${kind} enquiry`,
        text: `Name: ${name}\nEmail: ${email}\nType: ${kind}\n\n${message}`
      });
    } catch (e) { console.error("Email notification failed:", e.message); }
  }
  res.json({ message: "Thank you. Your enquiry has been received. Our team will follow up using the email address you provided." });
});

app.post("/api/admin/login", rateLimit({ windowMs: 15 * 60 * 1000, limit: 10 }), async (req, res) => {
  const email = clean(req.body.email, 160).toLowerCase();
  const password = String(req.body.password || "");
  const adminEmail = (process.env.ADMIN_EMAIL || "").toLowerCase();
  const configuredPassword = process.env.ADMIN_PASSWORD || "";
  if (!adminEmail || !configuredPassword || email !== adminEmail || password !== configuredPassword) {
    return res.status(401).json({ error: "Invalid credentials or admin credentials are not configured." });
  }
  req.session.admin = true;
  res.json({ message: "Signed in." });
});
app.post("/api/admin/logout", adminOnly, (req, res) => req.session.destroy(() => res.json({ message: "Signed out." })));
app.get("/api/admin/shipments", adminOnly, (req, res) => {
  const rows = db.prepare("SELECT tracking_number, recipient, destination, status, updated_at, events FROM shipments ORDER BY id DESC LIMIT 200").all();
  res.json(rows.map(r => ({ ...r, events: JSON.parse(r.events) })));
});
app.post("/api/admin/shipments", adminOnly, (req, res) => {
  const tracking = clean(req.body.trackingNumber, 40).toUpperCase();
  const recipient = clean(req.body.recipient, 100);
  const destination = clean(req.body.destination, 150);
  const status = clean(req.body.status || "Shipment information received", 100);
  if (!tracking || !recipient || !destination) return res.status(400).json({ error: "Tracking number, recipient, and destination are required." });
  const now = new Date().toISOString();
  const events = [{ status, location: destination, timestamp: now, note: "Shipment record created by authorized staff." }];
  try {
    db.prepare("INSERT INTO shipments (tracking_number,recipient,destination,status,updated_at,events) VALUES (?,?,?,?,?,?)")
      .run(tracking, recipient, destination, status, now, JSON.stringify(events));
    res.json({ message: "Shipment created." });
  } catch { res.status(409).json({ error: "That tracking number already exists." }); }
});
app.post("/api/admin/shipments/:number/events", adminOnly, (req, res) => {
  const number = clean(req.params.number, 40).toUpperCase();
  const status = clean(req.body.status, 100);
  const location = clean(req.body.location, 150);
  const note = clean(req.body.note, 500);
  if (!status || !location) return res.status(400).json({ error: "Status and location are required." });
  const row = db.prepare("SELECT events FROM shipments WHERE tracking_number = ?").get(number);
  if (!row) return res.status(404).json({ error: "Shipment not found." });
  const events = JSON.parse(row.events);
  events.unshift({ status, location, timestamp: new Date().toISOString(), note });
  db.prepare("UPDATE shipments SET status=?, updated_at=?, events=? WHERE tracking_number=?")
    .run(status, new Date().toISOString(), JSON.stringify(events), number);
  res.json({ message: "Tracking event added." });
});
app.get("/api/admin/enquiries", adminOnly, (req, res) => {
  res.json(db.prepare("SELECT * FROM enquiries ORDER BY id DESC LIMIT 200").all());
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Express Courier running at http://localhost:${port}`));
